export const Theme = {
    colors:{
        brandColor:'#E3244A',
    textColor:'#1E1E1E',
    darkColor:'#000',
        categoryColor:'#F5C6CD'
    },
    font:{
        Regular:'Spartan-Regular',
        Bold:'Spartan-Bold',
        ExtraBold:'Spartan-ExtraBold',
        Medium:'Spartan-Medium',
        SemiBold:'Spartan-SemiBold',
    },
    backgroundColor:'#fff',


}